-- Q1: Identify the most expensive SKU, on average, over the entire time period.

-- Q1: Most expensive SKU on average
SELECT SKU_NAME, 
       SUM(ORDERED_REVENUE) / NULLIF(SUM(ORDERED_UNITS), 0) AS avg_price
FROM Sales_Data
GROUP BY SKU_NAME
ORDER BY avg_price DESC
LIMIT 1;


-- Q2: What % of SKUs have generated some revenue in this time period?

-- Q2: % of SKUs with some revenue
SELECT 
    ROUND(100 * COUNT(DISTINCT CASE WHEN ORDERED_REVENUE > 0 THEN SKU_NAME END) 
          / COUNT(DISTINCT SKU_NAME), 2) AS revenue_generating_sku_percent
FROM Sales_Data;


-- Q2_brownie: Identify SKUs that stopped selling completely after July.

-- Q2 Bonus: SKUs that stopped selling after July
SELECT DISTINCT SKU_NAME
FROM Sales_Data
WHERE SKU_NAME NOT IN (
    SELECT DISTINCT SKU_NAME
    FROM Sales_Data
    WHERE MONTH(FEED_DATE) > 7 AND ORDERED_UNITS > 0
);


-- Q3: Identify the Sale Event dates.

-- Q3: Identify potential sale event days (spikes in revenue)
SELECT FEED_DATE, 
       SUM(ORDERED_REVENUE) AS total_revenue
FROM Sales_Data
GROUP BY FEED_DATE
ORDER BY total_revenue DESC
LIMIT 5;


-- Q4: Does having a sale event cannibalize sales in the immediate aftermath?

-- Q4: Analyze sales before and after peak sale days
-- (Replace '2019-07-15' with peak date from Q3 output)
SELECT
    CASE
        WHEN FEED_DATE BETWEEN DATE_SUB('2019-07-15', INTERVAL 3 DAY) AND DATE_SUB('2019-07-15', INTERVAL 1 DAY) THEN 'Before'
        WHEN FEED_DATE = '2019-07-15' THEN 'Peak'
        WHEN FEED_DATE BETWEEN DATE_ADD('2019-07-15', INTERVAL 1 DAY) AND DATE_ADD('2019-07-15', INTERVAL 3 DAY) THEN 'After'
    END AS period,
    AVG(ORDERED_REVENUE) AS avg_revenue
FROM Sales_Data
WHERE FEED_DATE BETWEEN DATE_SUB('2019-07-15', INTERVAL 3 DAY) AND DATE_ADD('2019-07-15', INTERVAL 3 DAY)
GROUP BY period;


-- Q5: Find subcategory growing slowest relative to its category.

-- Q5: Subcategory with slowest growth relative to its category
WITH growth AS (
    SELECT 
        CATEGORY,
        SUB_CATEGORY,
        MIN(FEED_DATE) AS start_date,
        MAX(FEED_DATE) AS end_date,
        SUM(CASE WHEN MONTH(FEED_DATE) = MONTH(MIN(FEED_DATE)) THEN ORDERED_UNITS ELSE 0 END) AS start_units,
        SUM(CASE WHEN MONTH(FEED_DATE) = MONTH(MAX(FEED_DATE)) THEN ORDERED_UNITS ELSE 0 END) AS end_units
    FROM Sales_Data
    GROUP BY CATEGORY, SUB_CATEGORY
)
SELECT CATEGORY, SUB_CATEGORY,
       start_units, end_units,
       ROUND((end_units - start_units) / NULLIF(start_units, 0), 2) AS growth_rate
FROM growth
ORDER BY growth_rate ASC
LIMIT 1;


-- Q6: Highlight anomalies/mismatches in the data.

-- Q6: Detect data anomalies (e.g., revenue with 0 units, negative values, missing views)
SELECT *
FROM Sales_Data
WHERE ORDERED_UNITS = 0 AND ORDERED_REVENUE > 0;

-- Also check for dates or SKUs present in one table but not the other
SELECT gv.SKU_NAME, gv.FEED_DATE
FROM Glance_Views gv
LEFT JOIN Sales_Data sd
ON gv.SKU_NAME = sd.SKU_NAME AND gv.FEED_DATE = sd.FEED_DATE
WHERE sd.SKU_NAME IS NULL;


-- Q7: Is Unit Conversion affected by Average Selling Price for SKU C120[H:8NV?

-- Q7: Correlation analysis using SQL approximation for SKU C120[H:8NV
SELECT 
    s.FEED_DATE,
    s.SKU_NAME,
    s.ORDERED_UNITS,
    g.VIEWS,
    s.ORDERED_REVENUE / NULLIF(s.ORDERED_UNITS, 0) AS avg_price,
    s.ORDERED_UNITS / NULLIF(g.VIEWS, 0) AS unit_conversion
FROM Sales_Data s
JOIN Glance_Views g
  ON s.SKU_NAME = g.SKU_NAME AND s.FEED_DATE = g.FEED_DATE
WHERE s.SKU_NAME = 'C120[H:8NV';


